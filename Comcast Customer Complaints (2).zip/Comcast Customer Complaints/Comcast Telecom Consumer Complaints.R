install.packages("stringi")
install.packages("lubridate")
install.packages("dplyr")
install.packages("ggplot2")
install.packages("ggpubr")
library("lubridate")
library("stringi")
library("dplyr")
library("ggplot2")
library("ggpubr")


# Selecting work directory

setwd("C:/Users/Dima/Desktop")
getwd()

# Importing Dataset

comcast <- read.csv("Copy of Comcast Telecom Complaints data.csv",head=TRUE,sep =";")
View(comcast)
str(comcast)

# Let's check if there is any missing data

comcastna <- is.na("comcast")
length(comcastna[comcastna==T])

# As per the results there is no missing values in the dataset

comcast$Date <- dmy(comcast$Date)

# Let's extract the monthly and daily count tickets

monthly_tickets <- summarise(group_by(comcast,month=as.integer(month(Date))),count=n())

# Let's remove the NA values
monthly_tickets <- na.omit(monthly_tickets)
daily_tickets <- summarise(group_by(comcast,Date),count=n())
daily_tickets <- na.omit(daily_tickets)
monthly_tickets <- arrange(monthly_tickets,month)

# Let's plot the monthly and daily complaints to perform a comparison

library(ggplot2)

ggplot(data = monthly_tickets,aes(month,count,label = count))+
  geom_line()+
  geom_point(size = 0.5)+
  geom_text()+
  scale_x_continuous(breaks = monthly_tickets$month)+
  labs(title = "Monthly Ticket Count",x= "Months",y ="No. of Tickets")+
  theme(plot.title = element_text(hjust = 0.5))


ggplot(data = daily_tickets,aes(as.POSIXct(Date),count))+
  geom_line()+
  geom_point(size = 1)+
  scale_x_datetime(breaks = "1 weeks",date_labels = "%d/%m")+
  labs(title = "Daily Ticket Count",x= "Days",y ="No. of Tickets")+
  theme(axis.text.x = element_text(angle = 75),
        plot.title = element_text(hjust = 0.5))

# Complaint Type Processing

network_issues <- contains(comcast$Customer.Complaint,match="network",ignore.case = T)
internet_issues <- contains(comcast$Customer.Complaint,match = "internet",ignore.case = T)
billing_issues <- contains(comcast$Customer.Complaint,match = "billing",ignore.case = T)
charges_issues <- contains(comcast$Customer.Complaint,match = "charge", ignore.case = T)
email_issues <- contains(comcast$Customer.Complaint,match = "email", ignore.case = T)

comcast$ComplaintType[internet_issues]<- "Internet"
comcast$ComplaintType[network_issues] <- "Network"
comcast$ComplaintType[billing_issues] <- "billing"
comcast$ComplaintType[charges_issues] <- "Charges"
comcast$ComplaintType[email_issues] <- "Email"

comcast$ComplaintType[-c(internet_issues,network_issues,billing_issues,charges_issues,email_issues)] <- "Others"

table(comcast$ComplaintType)

# Let's create a new categorical variable with value as Open and Closed

open_complaints <- (comcast$Status == "Open"| comcast$Status=="Pending")
closed_complaints <- (comcast$Status=="Closed"|comcast$Status=="Solved")
comcast$ComplaintStatus[open_complaints] <- "Open"
comcast$ComplaintStatus[closed_complaints] <- "Closed"

na_vector <- is.na(comcast)
length(na_vector[na_vector==T])
comcast <- subset(comcast,!is.na(comcast$ComplaintStatus))

# Let's plot in a barchart the State and Status of Tickets

comcast <- group_by(comcast,State,ComplaintStatus)
chart_data <- summarise(comcast,Count = n())
ggplot(as.data.frame(chart_data), mapping = aes(State,Count))+
  geom_col(aes(fill = ComplaintStatus),width = 0.95)+
  theme(axis.text.x = element_text(angle = 90),
        axis.title.y = element_text(size = 15),
        axis.title.x = element_text(size = 15),
        title = element_text(size = 16,colour = "#0073C2FF"),
        plot.title = element_text(hjust =  0.5))+
  labs(title = "Ticket Status",
       x = "States",y = "No of Tickets",
       fill= "Status")


# Provide the percentage of complaints resolved till date,which were received through the Internet and customer care calls

resolved <- group_by(comcast, ComplaintStatus)
total_resolved <- summarise(resolved,percentage=(n()/nrow(resolved)))
resolved <- group_by(comcast,Received.Via,ComplaintStatus)

Category_resloved<- summarise(resolved ,percentage =(n()/nrow(resolved))) 

# Let's plot this in a pie chart

par(mfrow = c(1,2))
total<-ggplot(total_resolved,
              aes(x= "",y =percentage,fill = ComplaintStatus))+
  geom_bar(stat = "identity",width = 1)+
  coord_polar("y",start = 0)+
  geom_text(aes(label = paste0(round(percentage*100),"%")),
            position = position_stack(vjust = 0.5))+
  labs(x = NULL,y = NULL,fill = NULL)+
  theme_classic()+theme(axis.line = element_blank(),
                        axis.text = element_blank(),
                        axis.ticks = element_blank())

# Pie Chart for Category wise Ticket Status

category<-ggplot(Category_resloved,
                 aes(x= "",y =percentage,fill = ComplaintStatus))+
  geom_bar(stat = "identity",width = 1)+
  coord_polar("y",start = 0)+
  geom_text(aes(label = paste0(Received.Via,"-",round(percentage*100),"%")),
            position = position_stack(vjust = 0.5))+
  labs(x = NULL,y = NULL,fill = NULL)+
  theme_classic()+theme(axis.line = element_blank(),
                        axis.text = element_blank(),
                        axis.ticks = element_blank())
ggarrange(total,category,nrow = 1, ncol = 2)


